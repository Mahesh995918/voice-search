import voiceLogo from './voice-icon.png';
import './App.css';
import { useState, useEffect } from 'react';
import { Dialog } from "@material-ui/core";

const SpeechRecognition =
  window.SpeechRecognition || window.webkitSpeechRecognition
const mic = new SpeechRecognition()

mic.continuous = true
mic.interimResults = true
mic.lang = 'en-US'

function App() {
  const [isListening, setIsListening] = useState(false)
  const [note, setNote] = useState(null)
  const [openListeningPopup, setOpenListeningPopup] = useState(false)


  useEffect(() => {
    handleListen();
  }, [isListening])

  const handleListen = () => {
    if (isListening) {
      mic.start()
      mic.onend = () => {
        console.log('continue..');
        mic.start()
      }
    } else {
      mic.stop()
      mic.onend = () => {
        console.log('Stopped Mic on Click');
      }
    }
    mic.onstart = () => {
      console.log('Mics on');
    }

    mic.onresult = event => {
      const transcript = Array.from(event.results)
        .map(result => result[0])
        .map(result => result.transcript)
        .join('')
      console.log(transcript);
      setNote(transcript)
      mic.onerror = event => {
        console.log(event.error);
      }
    }
  }

  const handleClose = () => {
    setOpenListeningPopup(false);
    setIsListening(false);
  }

  return (
    <div className="App">
      <div>
        <h1>Speech To Text</h1>
      </div>
      <div className="searchInputRow">
        <input type="text" placeholder="Search or type web address"></input>
        <span className="searchIcon"><i className="fa fa-search"></i></span>
        <span className="voiceIcon" onClick={() => setIsListening(prevState => !prevState, setOpenListeningPopup(true))}><img src={voiceLogo} title="Search by voice" alt="" /></span>
      </div>
      {/* <button onClick={resetTranscript}>Reset</button> */}
      <Dialog
        className="popup-details"
        open={openListeningPopup}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <button onClick={handleClose} className="colse-button"><i className="fa fa-times"></i></button>
        <div className="listening-popup">
          {isListening ? <p>Listening...</p> : <p>Try again</p>}
          <p>{note}</p>
          <figure onClick={() => setIsListening(prevState => !prevState)}>
            <img src={voiceLogo} alt="" />
          </figure>
          <p>Tab the microphone to try again</p>
        </div>
      </Dialog>
    </div>
  );
}

export default App;
